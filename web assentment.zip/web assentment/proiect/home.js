$(document).ready(function () {
    $('#setColorButton').on('click', function () {
        const selectedColor = $('#colorPicker').val();
        // Save the selected color to localStorage
        localStorage.setItem('backgroundColor', selectedColor);
        // Optionally, apply the color to the current page
        $('body').css('background-color', selectedColor);
    });

    // Redirect to store page when "Visit Store" button is clicked
    $('#visitStoreButton').on('click', function () {
        window.location.href = 'store.html'; // Assumes the other page is store.html
    });
});
