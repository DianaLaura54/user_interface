$(document).ready(function () {
    // Show loading animation
    $('#loading').show();
    $('#productList').hide();
    $('#categoryFilters').empty();
    $('#products').empty();

    // Retrieve and apply the saved background color
    const savedColor = localStorage.getItem('backgroundColor');
    if (savedColor) {
        $('body').css('background-color', savedColor);
    }

    // Fetch data from the API
    setTimeout(() => {
        $.ajax({
            url: 'https://fakestoreapi.com/products',
            method: 'GET',
            success: function (products) {
                $('#loading').hide();            // Hide loading indicator
                $('#productList').show();         // Show the product list
                $('.search-container').show();    // Show the search container
                displayCategories(products);      // Call to display categories
            },
            error: function () {
                $('#loading').hide();
                alert('Error loading products. Please try again.');
            }
        });
    }, 2000); // Simulate loading time of 2 seconds

    function displayCategories(products) {
        const categories = [
            { name: "men's clothing", image: 'https://fakestoreapi.com/img/71-3HjGNDUL._AC_SY879._SX._UX._SY._UY_.jpg' },
            { name: "women's clothing", image: 'https://fakestoreapi.com/img/81XH0e8fefL._AC_UY879_.jpg' },
            { name: 'electronics', image: 'https://fakestoreapi.com/img/61IBBVJvSDL._AC_SY879_.jpg' },
            { name: 'jewelery', image: 'https://fakestoreapi.com/img/71pWzhdJNwL._AC_UL640_QL65_ML3_.jpg' }
        ];

        categories.forEach(category => {
            const categoryHTML = `
                <div class="category">
                    <div>
                        <span>${category.name}</span>
                    </div>
                    <img src="${category.image}" alt="${category.name}">
                    <div>
                        <button class="filterButton" data-category="${category.name}">Filter ${category.name}</button>
                    </div>
                </div>
            `;
            $('#categoryFilters').append(categoryHTML);
        });

        // Add filter functionality to category buttons
        $('.filterButton').on('click', function () {
            const selectedCategory = $(this).data('category').toLowerCase();
            const filteredProducts = products.filter(product => product.category.toLowerCase() === selectedCategory);

            displayProducts(filteredProducts); // Display products from the selected category
        });
    }

    function displayProducts(products) {
        $('#products').empty(); // Clear previous products
    
        products.forEach(product => {
            const productHTML = `
                <div class="product">
                    <img src="${product.image}" alt="${product.title}">
                    <h3>${product.title}</h3>
                    <p><strong>Description:</strong> ${product.description}</p>
                    <p><strong>Category:</strong> ${product.category}</p>
                    <p><strong>Price:</strong> $${product.price}</p>
                    <p><strong>Rating:</strong> ${product.rating.rate} / 5 (${product.rating.count} reviews)</p>
                </div>
            `;
            $('#products').append(productHTML);
        });
    }

    // Search by Product ID functionality
    $('#productID').on('blur', function () {
        const productID = parseInt($(this).val(), 10); // Convert input to an integer

        // Check if the product ID is within valid range
        if (productID < 1 || productID > 20 || isNaN(productID)) {
            $(this).addClass('invalid-input').removeClass('valid-input'); // Add red border
            $('#errorMessage').text('Invalid product ID. Please enter a number between 1 and 20.');
            $('#productInfo').empty(); // Clear any previous product info
        } else {
            $(this).addClass('valid-input').removeClass('invalid-input'); // Add green border
            $('#errorMessage').empty(); // Clear any error message

            // Fetch the product data
            $.ajax({
                url: `https://fakestoreapi.com/products/${productID}`,
                method: 'GET',
                success: function (product) {
                    // Display the product's title and price
                    const productInfoHTML = `
                       <div class="product">
                    <img src="${product.image}" alt="${product.title}">
                    <h3>${product.title}</h3>
                    <p><strong>Description:</strong> ${product.description}</p>
                    <p><strong>Category:</strong> ${product.category}</p>
                    <p><strong>Price:</strong> $${product.price}</p>
                    <p><strong>Rating:</strong> ${product.rating.rate} / 5 (${product.rating.count} reviews)</p>
                </div>
                    `;
                    $('#productInfo').html(productInfoHTML);
                },
                error: function () {
                    $('#errorMessage').text('Product not found. Please try again.');
                }
            });
        }
    });
});
